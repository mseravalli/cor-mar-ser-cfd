#define C_F 16
/*#define C_B 0*/

#define B_N  1  /*0b00001*/
#define B_NO 9  /*0b01001*/
#define B_O  8  /*0b01000*/
#define B_SO 10 /*0b01010*/
#define B_S  2  /*0b00010*/
#define B_SW 6  /*0b00110*/
#define B_W  4  /*0b00100*/
#define B_NW 5  /*0b00101*/
#define B_C  0  /*0b00000*/
